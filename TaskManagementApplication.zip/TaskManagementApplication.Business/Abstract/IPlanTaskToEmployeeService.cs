﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Core.Business;
using TaskManagementApplication.Entities.Concrete;
using TaskManagementApplication.Entities.DTOs;

namespace TaskManagementApplication.Business.Abstract
{
    public interface IPlanTaskToEmployeeService : IService<PlanTaskToEmployee>
    {
        List<PlanTaskToEmployee> GetByEmployeeTask();
        List<PlanTaskToEmployeeDto> GetByEmployeeToTask();
    }
}

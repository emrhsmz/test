﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Core.Business;
using TaskManagementApplication.Entities.Concrete;

namespace TaskManagementApplication.Business.Abstract
{
    public interface IEmployeeService : IService<Employee>
    {
    }
}

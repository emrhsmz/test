﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Business.Abstract;
using TaskManagementApplication.DataAccess.Abstract;
using TaskManagementApplication.Entities.Concrete;

namespace TaskManagementApplication.Business.Concrete
{
    public class BucketManager : IBucketService
    {
        private readonly IBucketDal _bucketDal;

        public BucketManager(IBucketDal bucketDal)
        {
            _bucketDal = bucketDal;
        }

        public void Add(Bucket entity)
        {
            _bucketDal.Add(entity); 
        }

        public void Delete(Bucket entity)
        {
            _bucketDal.Delete(entity);
        }

        public List<Bucket> GetAll()
        {
            return _bucketDal.GetAll();
        }

        public List<Bucket> GetAll(Guid id)
        {
            return _bucketDal.GetAll(a=>a.Id == id);
        }

        public Bucket GetById(Guid id)
        {
            return _bucketDal.Get(a => a.Id == id);
        }

        public List<Bucket> GetWithPlanAll()
        {
            return _bucketDal.GetWithPlanAll();
        }

        public List<Bucket> GetWithPlanEmployeeAll()
        {
            return _bucketDal.GetWithPlanEmployeeAll();
        }

        public void Update(Bucket entity)
        {
            _bucketDal.Update(entity);
        }
    }
}

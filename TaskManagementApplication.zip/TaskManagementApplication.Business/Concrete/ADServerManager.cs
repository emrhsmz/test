﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Business.Abstract;
using TaskManagementApplication.DataAccess.Abstract;
using TaskManagementApplication.Entities.Concrete;

namespace TaskManagementApplication.Business.Concrete
{
    public class ADServerManager : IADServerService
    {
        private readonly IADServerDal _aDServerDal;

        public ADServerManager(IADServerDal aDServerDal)
        {
            _aDServerDal = aDServerDal;
        }

        public void Add(ADServer entity)
        {
            _aDServerDal.Add(entity);
        }

        public void Delete(ADServer entity)
        {
            _aDServerDal.Delete(entity);
        }

        public List<ADServer> GetAll()
        {
            return _aDServerDal.GetAll();
        }

        public List<ADServer> GetAll(Guid id)
        {
            return _aDServerDal.GetAll(p => p.Id == id);
        }

        public ADServer GetById(Guid id)
        {
            return _aDServerDal.Get(a => a.Id == id);
        }
        public void Update(ADServer entity)
        {
            _aDServerDal.Update(entity);
        }
    }
}

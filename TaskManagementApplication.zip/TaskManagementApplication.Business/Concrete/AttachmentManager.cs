﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Business.Abstract;
using TaskManagementApplication.DataAccess.Abstract;
using TaskManagementApplication.Entities.Concrete;

namespace TaskManagementApplication.Business.Concrete
{
    public class AttachmentManager : IAttachmentService
    {
        private readonly IAttachmentDal _attachmentDal;

        public AttachmentManager(IAttachmentDal attachmentDal)
        {
            _attachmentDal = attachmentDal;
        }

        public void Add(Attachment entity)
        {
            _attachmentDal.Add(entity);
        }

        public void Delete(Attachment entity)
        {
            _attachmentDal.Delete(entity);
        }

        public List<Attachment> GetAll()
        {
            return _attachmentDal.GetAll();
        }

        public List<Attachment> GetAll(Guid id)
        {
            return _attachmentDal.GetAll(a => a.Id == id);
        }

        public Attachment GetById(Guid id)
        {
            return _attachmentDal.Get(a=>a.Id == id);
        }

        public void Update(Attachment entity)
        {
            _attachmentDal.Update(entity);
        }
    }
}

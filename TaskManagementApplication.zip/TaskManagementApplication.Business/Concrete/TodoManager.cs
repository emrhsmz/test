﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Business.Abstract;
using TaskManagementApplication.DataAccess.Abstract;
using TaskManagementApplication.Entities.Concrete;

namespace TaskManagementApplication.Business.Concrete
{
    public class TodoManager : ITodoService
    {
        private readonly ITodoDal _todoDal;

        public TodoManager(ITodoDal todoDal)
        {
            _todoDal = todoDal;
        }

        public void Add(Todo entity)
        {
            _todoDal.Add(entity);
        }

        public void Delete(Todo entity)
        {
            _todoDal.Delete(entity);
        }

        public List<Todo> GetAll()
        {
            return _todoDal.GetAll();
        }

        public List<Todo> GetAll(Guid id)
        {
            return _todoDal.GetAll(a=>a.Id == id);
        }

        public Todo GetById(Guid id)
        {
            return _todoDal.Get(a => a.Id == id);
        }

        public void Update(Todo entity)
        {
            _todoDal.Update(entity);
        }
    }
}

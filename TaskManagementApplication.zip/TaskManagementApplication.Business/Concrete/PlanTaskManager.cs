﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Business.Abstract;
using TaskManagementApplication.DataAccess.Abstract;
using TaskManagementApplication.Entities.Concrete;

namespace TaskManagementApplication.Business.Concrete
{
    public class PlanTaskManager : IPlanTaskService
    {
        private readonly IPlanTaskDal _planTaskDal;

        public PlanTaskManager(IPlanTaskDal planTaskDal)
        {
            _planTaskDal = planTaskDal;
        }

        public void Add(PlanTask entity)
        {
            _planTaskDal.Add(entity);
        }

        public void Delete(PlanTask entity)
        {
            _planTaskDal.Delete(entity);
        }

        public List<PlanTask> GetAll()
        {
            return _planTaskDal.GetAll();
        }

        public List<PlanTask> GetAll(Guid id)
        {
            return _planTaskDal.GetAll(a => a.Id == id);
        }

        public List<PlanTaskToEmployee> GetByEmployeeTask()
        {
            return _planTaskDal.GetByEmployeeTask();
        }

        public PlanTask GetById(Guid id)
        {
            return _planTaskDal.Get(a => a.Id == id);
        }

        public List<PlanTask> GetWithEmployeeAll()
        {
            return _planTaskDal.GetWithEmployeeAll();
        }

        public List<PlanTask> GetWithOtherTable()
        {
            return _planTaskDal.GetWithOtherTable();
        }

        public void Update(PlanTask entity)
        {
            _planTaskDal.Update(entity);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Business.Abstract;
using TaskManagementApplication.DataAccess.Abstract;
using TaskManagementApplication.Entities.Concrete;

namespace TaskManagementApplication.Business.Concrete
{
    public class PlanManager : IPlanService
    {
        private readonly IPlanDal _planDal;

        public PlanManager(IPlanDal planDal)
        {
            _planDal = planDal;
        }

        public void Add(Plan entity)
        {
            _planDal.Add(entity);
        }

        public void Delete(Plan entity)
        {
            _planDal.Delete(entity);
        }

        public List<Plan> GetAll()
        {
            return _planDal.GetAll();
        }

        public List<Plan> GetAll(Guid id)
        {
            return _planDal.GetAll(a=>a.Id == id);
        }

        public Plan GetById(Guid id)
        {
            return _planDal.Get(a => a.Id == id);
        }

        public void Update(Plan entity)
        {
            _planDal.Update(entity);
        }
    }
}

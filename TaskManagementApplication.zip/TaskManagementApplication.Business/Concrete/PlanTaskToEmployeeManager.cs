﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplication.Business.Abstract;
using TaskManagementApplication.DataAccess.Abstract;
using TaskManagementApplication.Entities.Concrete;
using TaskManagementApplication.Entities.DTOs;

namespace TaskManagementApplication.Business.Concrete
{
    public class PlanTaskToEmployeeManager : IPlanTaskToEmployeeService
    {
        private readonly IPlanTaskToEmployeeDal _planTaskToEmployeeDal;

        public PlanTaskToEmployeeManager(IPlanTaskToEmployeeDal planTaskToEmployeeDal)
        {
            _planTaskToEmployeeDal = planTaskToEmployeeDal;
        }

        public void Add(PlanTaskToEmployee entity)
        {
            _planTaskToEmployeeDal.Add(entity);
        }

        public void Delete(PlanTaskToEmployee entity)
        {
            _planTaskToEmployeeDal.Delete(entity);
        }

        public List<PlanTaskToEmployee> GetAll()
        {
            return _planTaskToEmployeeDal.GetAll();
        }

        public List<PlanTaskToEmployee> GetAll(Guid id)
        {
            return _planTaskToEmployeeDal.GetAll(a => a.PlanTaskId == id);
        }
        public List<PlanTaskToEmployee> GetByEmployeeTask()
        {
            return _planTaskToEmployeeDal.GetByEmployeeTask();
        }

        public List<PlanTaskToEmployeeDto> GetByEmployeeToTask()
        {
            return _planTaskToEmployeeDal.GetByEmployeeToTask();
        }

        public PlanTaskToEmployee GetById(Guid id)
        {
            return _planTaskToEmployeeDal.Get(a => a.PlanTaskId == id);
        }

        public void Update(PlanTaskToEmployee entity)
        {
            _planTaskToEmployeeDal.Update(entity);
        }
    }
}
